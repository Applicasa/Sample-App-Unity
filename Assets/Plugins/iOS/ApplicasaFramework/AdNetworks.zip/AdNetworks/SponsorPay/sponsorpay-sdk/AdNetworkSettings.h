
//  ThirdPartySettings.h
//  SponsorPay iOS SDK
//
// Copyright 2011-2013 SponsorPay. All rights reserved.
//

/******************************************************
 * Configuration for the Vungle SDK
 ******************************************************/

// Define SPVungleSDKAvailable_1_3_2 to enable support for the Vungle SDK versions 1.3.2. to 1.4.3
//#define SPVungleSDKAvailable_1_3_2

//#define SPVungleAppID @"518234fc3e82594956000007"


/******************************************************
 * Configuration for the Flurry SDK
 ******************************************************/

// Define SPFlurrySDKAvailable_4_2_1 to enable support for the Flurry SDK versions 4.2.1 to 4.2.3
//#define SPFlurrySDKAvailable_4_2_1
//#define SPFlurryAPIKey @"7TGX5C5S3XK633XSVMBB"
//#define SPFlurryVideoAdsSpace @"INTERSTITIAL_MAIN_VC"
